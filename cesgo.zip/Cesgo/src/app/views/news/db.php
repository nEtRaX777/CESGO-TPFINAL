<?php
    $conexion=mysqli_connect("localhost","root","","trabajoFinal");
?>
<H1>CONECTADO</H1>