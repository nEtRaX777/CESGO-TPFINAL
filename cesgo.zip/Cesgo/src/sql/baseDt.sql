create database trabajoFinal;

use trabajoFinal;

CREATE TABLE empleados
(
    nombre varchar(50),
    apellido varchar(50),
    puesto varchar(70),
    dni int(30),
    id_tarjeta int(30),
    usuario varchar(50),
    pass varchar(50)
);
CREATE TABLE productos
(
    nombre varchar(70),
    id int(30),
    cantidad int(10),
    provedor varchar(50),
    producto varchar(50),
    id_ingreso int(50) auto_increment primary key,
    id_empleado int(50),
    fecha datetime
);


select * 
from TableLogin 
where (mail = 'lucianocespedes02@gmail.com' and contrasena ='1161928662');

select * 
from empleados;
select * 
from productos;